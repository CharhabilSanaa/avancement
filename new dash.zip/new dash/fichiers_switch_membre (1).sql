-- phpMyAdmin SQL Dump
-- version 4.0.10deb1ubuntu0.1
-- http://www.phpmyadmin.net
--
-- Client: localhost
-- Généré le: Ven 17 Juin 2022 à 20:31
-- Version du serveur: 5.5.62-0ubuntu0.14.04.1
-- Version de PHP: 5.5.9-1ubuntu4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données: `fichiers_switch_membre`
--

-- --------------------------------------------------------

--
-- Structure de la table `bank_informations`
--

CREATE TABLE IF NOT EXISTS `bank_informations` (
  `id_auto` int(11) NOT NULL AUTO_INCREMENT,
  `bank_code` int(6) unsigned zerofill NOT NULL,
  `category` varchar(2) NOT NULL,
  `center_code` int(2) NOT NULL,
  `bank_name` varchar(50) NOT NULL,
  `abrev_name` varchar(14) NOT NULL,
  `address_1` text NOT NULL,
  `city_code` varchar(10) NOT NULL,
  `zip_code` int(5) NOT NULL,
  `region_code` varchar(4) NOT NULL,
  `country_code` int(10) NOT NULL,
  `phone_1` varchar(15) NOT NULL,
  `phone_2` varchar(15) NOT NULL,
  `fax_number` varchar(15) NOT NULL,
  `email` text NOT NULL,
  `web_url` text NOT NULL,
  `bank_member_ind` varchar(2) NOT NULL,
  `checking_account_ind` varchar(2) NOT NULL,
  `transmission_mode` varchar(2) NOT NULL,
  `multi_country_ind` varchar(2) NOT NULL,
  `public_bank_id` int(6) NOT NULL,
  `contact_name` varchar(50) NOT NULL,
  `contact_phone` varchar(15) NOT NULL,
  `vat` int(10) NOT NULL,
  `eff_date_vat` date NOT NULL,
  `former_vat` int(10) NOT NULL,
  `interest_vat` int(10) NOT NULL,
  `interest_eff_date_vat` date NOT NULL,
  `interest_former_vat` int(10) NOT NULL,
  `fund` int(10) NOT NULL,
  `eff_date_fund` date NOT NULL,
  `former_fund` int(10) NOT NULL,
  `bank_currency_code` int(10) NOT NULL,
  `zip_code_option` varchar(5) NOT NULL,
  `ctrl_client_len` int(10) NOT NULL,
  `ctrl_client_key` varchar(5) NOT NULL,
  `ctrl_shadow_account_len` int(10) NOT NULL,
  `ctrl_shadow_account_key` varchar(5) NOT NULL,
  `ctrl_account_len` int(5) NOT NULL,
  `ctrl_account_key` varchar(5) NOT NULL,
  `ctrl_chain_len` int(5) NOT NULL,
  `ctrl_chain_key` varchar(5) NOT NULL,
  `ctrl_merchant_len` int(5) NOT NULL,
  `ctrl_merchant_key` varchar(5) NOT NULL,
  `ctrl_outlet_len` int(5) NOT NULL,
  `ctrl_outlet_key` varchar(5) NOT NULL,
  `renew_print_delay` varchar(5) NOT NULL,
  `delivery_default` varchar(5) NOT NULL,
  `daily_autho_number_alert` varchar(5) NOT NULL,
  `account_number` varchar(15) NOT NULL,
  `key_account` varchar(5) NOT NULL,
  `status` varchar(5) NOT NULL,
  `status_date` date NOT NULL,
  `user_create` varchar(10) NOT NULL,
  `date_create` datetime NOT NULL,
  PRIMARY KEY (`id_auto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `cellule_bank`
--

CREATE TABLE IF NOT EXISTS `cellule_bank` (
  `id_auto` int(4) NOT NULL AUTO_INCREMENT,
  `libelle_bank` varchar(10) NOT NULL,
  `etat_bank` int(2) NOT NULL,
  `libelle` varchar(2) NOT NULL,
  `etat` int(1) NOT NULL,
  PRIMARY KEY (`id_auto`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=27 ;

--
-- Contenu de la table `cellule_bank`
--

INSERT INTO `cellule_bank` (`id_auto`, `libelle_bank`, `etat_bank`, `libelle`, `etat`) VALUES
(1, 'Arab_Bank', 1, 'A', 1),
(2, 'AWB', 1, 'B', 1),
(3, 'BARID', 1, 'C', 0),
(4, 'BCP', 1, 'D', 1),
(5, 'BMCE', 1, 'E', 1),
(6, 'BMCI', 1, 'F', 1),
(7, 'CAM', 1, 'G', 1),
(8, 'CDM', 1, 'H', 1),
(9, 'CFG', 1, 'I', 1),
(10, 'CIH', 1, 'J', 1),
(11, 'DAA', 1, 'K', 1),
(12, 'SGMB', 1, 'L', 1),
(13, 'UMNIA', 1, 'M', 1),
(15, 'AKB', 2, '', 0),
(16, 'ARREDA', 2, '', 0),
(17, 'BARID_CASH', 2, '', 0),
(18, 'BKS', 2, '', 0),
(19, 'Cash_plus', 2, '', 0),
(20, 'DAMAN_CASH', 2, '', 0),
(21, 'NAPS', 2, '', 0),
(22, 'UMB', 2, '', 0),
(23, 'BAY', 2, '', 0),
(24, 'CDG', 2, '', 0),
(25, 'Cetelem', 2, '', 0),
(26, 'NAJMAH', 2, '', 0);

-- --------------------------------------------------------

--
-- Structure de la table `global_per_hour_all`
--

CREATE TABLE IF NOT EXISTS `global_per_hour_all` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_` datetime NOT NULL,
  `day` text NOT NULL,
  `nombre_author` int(11) NOT NULL,
  `bank` varchar(15) NOT NULL,
  `nbr_rejet_tech` int(11) NOT NULL,
  `pourcentage_tech` float NOT NULL,
  `h0` int(11) NOT NULL,
  `h1` int(11) NOT NULL,
  `h2` int(11) NOT NULL,
  `h3` int(11) NOT NULL,
  `h4` int(11) NOT NULL,
  `h5` int(11) NOT NULL,
  `h6` int(11) NOT NULL,
  `h7` int(11) NOT NULL,
  `h8` int(11) NOT NULL,
  `h9` int(11) NOT NULL,
  `h10` int(11) NOT NULL,
  `h11` int(11) NOT NULL,
  `h12` int(11) NOT NULL,
  `h13` int(11) NOT NULL,
  `h14` int(11) NOT NULL,
  `h15` int(11) NOT NULL,
  `h16` int(11) NOT NULL,
  `h17` int(11) NOT NULL,
  `h18` int(11) NOT NULL,
  `h19` int(11) NOT NULL,
  `h20` int(11) NOT NULL,
  `h21` int(11) NOT NULL,
  `h22` int(11) NOT NULL,
  `h23` int(11) NOT NULL,
  `date_insertion` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Contenu de la table `global_per_hour_all`
--

INSERT INTO `global_per_hour_all` (`id`, `date_`, `day`, `nombre_author`, `bank`, `nbr_rejet_tech`, `pourcentage_tech`, `h0`, `h1`, `h2`, `h3`, `h4`, `h5`, `h6`, `h7`, `h8`, `h9`, `h10`, `h11`, `h12`, `h13`, `h14`, `h15`, `h16`, `h17`, `h18`, `h19`, `h20`, `h21`, `h22`, `h23`, `date_insertion`) VALUES
(1, '2022-06-15 00:00:00', 'Mer.', 109057, 'CIH', 5, 0.02, 963, 525, 281, 233, 156, 419, 1193, 2352, 3218, 4029, 5292, 7524, 8192, 6899, 6418, 6880, 8099, 9982, 10239, 9174, 7758, 4649, 2935, 1647, '2022-06-16 16:24:33'),
(2, '2022-06-15 00:00:00', 'Mer.', 4029, 'BKS', 1, 0, 2, 1, 6, 4, 6, 22, 74, 151, 165, 200, 253, 361, 316, 254, 233, 196, 275, 412, 334, 296, 223, 131, 88, 26, '2022-06-16 16:24:33'),
(3, '2022-06-15 00:00:00', 'Mer.', 98278, 'BCP', 369, 0.01, 611, 356, 223, 160, 156, 352, 1094, 2384, 3318, 4559, 5531, 7330, 7300, 6400, 5828, 6474, 7459, 8669, 8927, 7789, 6356, 3433, 2415, 1154, '2022-06-16 16:24:33'),
(4, '2022-06-15 00:00:00', 'Mer.', 37756, 'BARID', 523, 0.29, 215, 310, 280, 66, 82, 213, 547, 885, 1301, 1792, 2261, 2697, 2329, 2083, 1998, 2194, 2612, 3400, 3639, 3305, 2764, 1480, 888, 415, '2022-06-16 16:24:33'),
(5, '2022-06-15 00:00:00', 'Mer.', 49827, 'SGMB', 1, 0.03, 309, 142, 149, 67, 96, 196, 595, 1399, 1827, 2422, 2957, 3881, 3885, 3265, 2931, 3141, 3795, 4490, 4481, 3683, 2939, 1705, 928, 544, '2022-06-16 16:24:33'),
(6, '2022-06-15 00:00:00', 'Mer.', 106349, 'AWB', 3, 0, 781, 474, 262, 197, 204, 438, 1175, 2363, 3772, 5046, 6415, 8014, 8149, 6840, 6551, 6986, 8025, 9220, 9621, 7913, 6634, 3814, 2198, 1257, '2022-06-16 16:24:33'),
(7, '2022-06-15 00:00:00', 'Mer.', 3418, 'BARID_CASH', 2, 0.97, 19, 5, 4, 8, 7, 21, 51, 85, 130, 165, 196, 249, 259, 195, 166, 206, 237, 275, 378, 275, 254, 133, 62, 38, '2022-06-16 16:24:33'),
(8, '2022-06-15 00:00:00', 'Mer.', 140, 'Arab_Bank', 5, 5.71, 0, 0, 0, 0, 0, 0, 0, 4, 5, 8, 14, 8, 13, 13, 16, 8, 10, 8, 9, 7, 6, 2, 3, 6, '2022-06-16 16:24:33'),
(9, '2022-06-15 00:00:00', 'Mer.', 54, 'NAJMAH', 5, 7.41, 0, 0, 0, 0, 0, 0, 6, 3, 1, 1, 0, 4, 2, 3, 2, 4, 3, 7, 10, 4, 1, 3, 0, 0, '2022-06-16 16:24:33'),
(10, '2022-06-15 00:00:00', 'Mer.', 20603, 'BMCI', 8, 0.4, 117, 39, 35, 17, 37, 149, 330, 568, 849, 1060, 1291, 1674, 1562, 1399, 1204, 1333, 1574, 1834, 1804, 1453, 1099, 653, 328, 194, '2022-06-16 16:24:33'),
(11, '2022-06-15 00:00:00', 'Mer.', 17858, 'CAM', 3, 0.62, 103, 96, 30, 31, 40, 97, 253, 453, 684, 960, 1172, 1342, 1320, 1138, 1053, 1136, 1299, 1478, 1481, 1290, 1100, 643, 399, 260, '2022-06-16 16:24:33'),
(12, '2022-06-15 00:00:00', 'Mer.', 78, 'DAMAN_CASH', 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1, 13, 5, 8, 2, 8, 1, 4, 7, 8, 5, 4, 7, 2, 1, 0, '2022-06-16 16:24:33'),
(13, '2022-06-15 00:00:00', 'Mer.', 84, 'Cetelem', 0, 0, 0, 0, 0, 0, 0, 1, 2, 2, 5, 7, 12, 9, 4, 4, 8, 1, 3, 5, 8, 4, 8, 0, 1, 0, '2022-06-16 16:24:33'),
(14, '2022-06-15 00:00:00', 'Mer.', 1176, 'Cash_plus', 0, 0, 18, 3, 0, 2, 2, 4, 13, 20, 42, 75, 78, 99, 80, 70, 63, 93, 79, 98, 111, 76, 72, 41, 18, 19, '2022-06-16 16:24:33'),
(15, '2022-06-15 00:00:00', 'Mer.', 793, 'AKB', 2, 0, 2, 0, 0, 0, 0, 3, 7, 32, 46, 41, 45, 63, 56, 36, 36, 50, 46, 79, 65, 73, 56, 32, 15, 10, '2022-06-16 16:24:33'),
(16, '2022-06-15 00:00:00', 'Mer.', 26701, 'CDM', 8, 0.02, 163, 84, 42, 47, 38, 111, 340, 650, 1075, 1482, 1672, 2116, 2044, 1779, 1628, 1782, 1986, 2311, 2233, 1887, 1535, 840, 569, 287, '2022-06-16 16:24:33'),
(17, '2022-06-15 00:00:00', 'Mer.', 4999, 'UMNIA', 14, 0.02, 6, 3, 3, 1, 12, 19, 73, 174, 202, 228, 284, 421, 337, 282, 249, 308, 380, 473, 457, 380, 334, 204, 126, 43, '2022-06-16 16:24:33'),
(18, '2022-06-15 00:00:00', 'Mer.', 10, 'CDG', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 3, 0, 3, 0, 0, 1, 0, 0, 0, '2022-06-16 16:24:33'),
(19, '2022-06-15 00:00:00', 'Mer.', 65686, 'BMCE', 5, 0.37, 461, 282, 169, 125, 141, 287, 775, 1623, 2398, 3146, 3954, 4880, 4836, 4215, 4046, 4187, 4940, 5727, 5676, 4987, 4202, 2412, 1401, 816, '2022-06-16 16:24:33'),
(20, '2022-06-15 00:00:00', 'Mer.', 8087, 'CFG', 43, 0, 84, 46, 23, 7, 11, 26, 71, 182, 308, 409, 474, 588, 696, 632, 518, 606, 586, 674, 609, 536, 423, 274, 172, 132, '2022-06-16 16:24:33'),
(21, '2022-06-15 00:00:00', 'Mer.', 937, 'BAY', 1, 0.21, 7, 3, 3, 0, 1, 7, 9, 31, 45, 78, 54, 62, 75, 71, 43, 61, 63, 65, 69, 58, 65, 38, 25, 4, '2022-06-16 16:24:33'),
(22, '2022-06-15 00:00:00', 'Mer.', 1769, 'DAA', 12, 0, 4, 3, 2, 1, 6, 11, 35, 75, 90, 72, 106, 133, 136, 106, 92, 91, 121, 171, 171, 146, 98, 49, 32, 18, '2022-06-16 16:24:33'),
(23, '2022-06-15 00:00:00', 'Mer.', 732, 'NAPS', 17, 0.14, 8, 0, 1, 0, 0, 1, 11, 3, 30, 52, 55, 67, 72, 33, 27, 49, 38, 61, 91, 58, 33, 22, 15, 5, '2022-06-16 16:24:33'),
(24, '2022-06-15 00:00:00', 'Mer.', 300, 'ARREDA', 9, 3, 0, 0, 3, 1, 0, 2, 8, 18, 16, 20, 9, 22, 30, 17, 8, 12, 25, 22, 30, 20, 13, 11, 4, 9, '2022-06-16 16:24:33'),
(25, '2022-06-15 00:00:00', 'Mer.', 43, 'UMB', 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 7, 10, 3, 2, 3, 2, 1, 2, 3, 4, 4, 0, 0, 0, '2022-06-16 16:24:33');

-- --------------------------------------------------------

--
-- Structure de la table `global_per_hour_atm`
--

CREATE TABLE IF NOT EXISTS `global_per_hour_atm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_` datetime NOT NULL,
  `day` text NOT NULL,
  `nombre_author` int(11) NOT NULL,
  `bank` varchar(15) NOT NULL,
  `nbr_rejets_tech` int(11) NOT NULL,
  `pourcentage_rejets_tech` float NOT NULL,
  `h0` int(11) NOT NULL,
  `h1` int(11) NOT NULL,
  `h2` int(11) NOT NULL,
  `h3` int(11) NOT NULL,
  `h4` int(11) NOT NULL,
  `h5` int(11) NOT NULL,
  `h6` int(11) NOT NULL,
  `h7` int(11) NOT NULL,
  `h8` int(11) NOT NULL,
  `h9` int(11) NOT NULL,
  `h10` int(11) NOT NULL,
  `h11` int(11) NOT NULL,
  `h12` int(11) NOT NULL,
  `h13` int(11) NOT NULL,
  `h14` int(11) NOT NULL,
  `h15` int(11) NOT NULL,
  `h16` int(11) NOT NULL,
  `h17` int(11) NOT NULL,
  `h18` int(11) NOT NULL,
  `h19` int(11) NOT NULL,
  `h20` int(11) NOT NULL,
  `h21` int(11) NOT NULL,
  `h22` int(11) NOT NULL,
  `h23` int(11) NOT NULL,
  `date_insertion` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Contenu de la table `global_per_hour_atm`
--

INSERT INTO `global_per_hour_atm` (`id`, `date_`, `day`, `nombre_author`, `bank`, `nbr_rejets_tech`, `pourcentage_rejets_tech`, `h0`, `h1`, `h2`, `h3`, `h4`, `h5`, `h6`, `h7`, `h8`, `h9`, `h10`, `h11`, `h12`, `h13`, `h14`, `h15`, `h16`, `h17`, `h18`, `h19`, `h20`, `h21`, `h22`, `h23`, `date_insertion`) VALUES
(1, '2022-06-15 00:00:00', 'Mer.', 29632, 'CIH', 2, 0, 121, 78, 56, 42, 51, 176, 429, 896, 1090, 1370, 1740, 2208, 2335, 1905, 1728, 1809, 2177, 2572, 2581, 2241, 1885, 1171, 673, 298, '2022-06-17 12:30:56'),
(2, '2022-06-15 00:00:00', 'Mer.', 2494, 'BKS', 1, 0, 1, 0, 2, 2, 3, 17, 52, 102, 119, 147, 165, 220, 177, 177, 164, 111, 159, 250, 193, 155, 138, 78, 53, 9, '2022-06-17 12:30:56'),
(3, '2022-06-15 00:00:00', 'Mer.', 19619, 'BARID', 364, 0, 71, 167, 172, 31, 58, 149, 351, 582, 819, 1038, 1335, 1434, 1108, 1015, 970, 1111, 1270, 1788, 1893, 1557, 1303, 785, 449, 163, '2022-06-17 12:30:56'),
(4, '2022-06-15 00:00:00', 'Mer.', 14450, 'BCP', 37, 0, 63, 60, 45, 27, 45, 77, 237, 499, 622, 876, 940, 1189, 1115, 1036, 873, 894, 1032, 1160, 1103, 901, 760, 463, 284, 149, '2022-06-17 12:30:56'),
(5, '2022-06-15 00:00:00', 'Mer.', 22591, 'AWB', 1, 0, 143, 95, 57, 45, 84, 148, 358, 697, 937, 1286, 1497, 1665, 1668, 1328, 1276, 1331, 1615, 1875, 1929, 1530, 1356, 870, 505, 296, '2022-06-17 12:30:56'),
(6, '2022-06-15 00:00:00', 'Mer.', 12550, 'SGMB', 15, 0, 33, 20, 14, 18, 38, 96, 259, 443, 531, 677, 781, 975, 854, 796, 711, 765, 982, 1172, 1100, 838, 701, 431, 211, 104, '2022-06-17 12:30:56'),
(7, '2022-06-15 00:00:00', 'Mer.', 2899, 'B_CASH', 34, 1, 15, 2, 2, 6, 7, 21, 50, 75, 110, 143, 175, 218, 216, 167, 140, 172, 212, 236, 304, 228, 208, 121, 52, 19, '2022-06-17 12:30:56'),
(8, '2022-06-15 00:00:00', 'Mer.', 41, 'NAJMAH', 1, 0, 0, 0, 0, 0, 0, 0, 6, 3, 1, 0, 0, 3, 1, 2, 2, 3, 3, 4, 5, 4, 1, 3, 0, 0, '2022-06-17 12:30:56'),
(9, '2022-06-15 00:00:00', 'Mer.', 59, 'A_Bank', 8, 8, 0, 0, 0, 0, 0, 0, 0, 4, 1, 5, 8, 5, 5, 6, 8, 2, 2, 3, 2, 1, 1, 1, 1, 4, '2022-06-17 12:30:56'),
(10, '2022-06-15 00:00:00', 'Mer.', 5571, 'BMCI', 22, 0, 10, 12, 6, 5, 22, 80, 167, 200, 263, 325, 361, 462, 389, 292, 330, 315, 418, 501, 437, 385, 289, 168, 80, 54, '2022-06-17 12:30:56'),
(11, '2022-06-15 00:00:00', 'Mer.', 6930, 'CAM', 3, 1, 33, 37, 11, 9, 25, 42, 140, 226, 336, 425, 505, 515, 495, 466, 390, 398, 467, 623, 546, 429, 376, 241, 132, 63, '2022-06-17 12:30:56'),
(12, '2022-06-15 00:00:00', 'Mer.', 31, 'D_CASH', 1, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 5, 1, 2, 0, 1, 1, 3, 4, 1, 3, 3, 3, 2, 0, 0, '2022-06-17 12:30:56'),
(13, '2022-06-15 00:00:00', 'Mer.', 84, 'Cetelem', 0, 0, 0, 0, 0, 0, 0, 1, 2, 2, 5, 7, 12, 9, 4, 4, 8, 1, 3, 5, 8, 4, 8, 0, 1, 0, '2022-06-17 12:30:56'),
(14, '2022-06-15 00:00:00', 'Mer.', 610, 'C_plus', 1, 0, 13, 1, 0, 1, 1, 1, 9, 5, 16, 19, 34, 50, 28, 28, 27, 61, 47, 69, 55, 43, 51, 29, 12, 10, '2022-06-17 12:30:56'),
(15, '2022-06-15 00:00:00', 'Mer.', 407, 'AKB', 1, 0, 1, 0, 0, 0, 0, 2, 3, 19, 27, 24, 26, 35, 33, 19, 21, 30, 17, 46, 24, 29, 22, 18, 7, 4, '2022-06-17 12:30:56'),
(16, '2022-06-15 00:00:00', 'Mer.', 7563, 'CDM', 1, 0, 37, 20, 8, 13, 16, 42, 151, 280, 379, 472, 532, 628, 558, 461, 410, 475, 517, 658, 614, 467, 392, 234, 123, 76, '2022-06-17 12:30:56'),
(17, '2022-06-15 00:00:00', 'Mer.', 2966, 'UMNIA', 4, 0, 2, 2, 1, 0, 8, 15, 46, 118, 131, 148, 194, 265, 173, 175, 141, 165, 217, 271, 259, 201, 202, 138, 71, 23, '2022-06-17 12:30:56'),
(18, '2022-06-15 00:00:00', 'Mer.', 1, 'CDG', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, '2022-06-17 12:30:56'),
(19, '2022-06-15 00:00:00', 'Mer.', 15791, 'BMCE', 141, 0, 50, 63, 29, 26, 56, 114, 288, 523, 695, 873, 1062, 1174, 1128, 947, 911, 938, 1093, 1387, 1279, 1130, 937, 596, 308, 184, '2022-06-17 12:30:56'),
(20, '2022-06-15 00:00:00', 'Mer.', 1524, 'CFG', 7, 0, 15, 4, 1, 1, 3, 5, 19, 61, 85, 100, 98, 102, 154, 127, 80, 112, 117, 132, 82, 79, 73, 38, 22, 14, '2022-06-17 12:30:56'),
(21, '2022-06-15 00:00:00', 'Mer.', 515, 'BAY', 1, 0, 3, 1, 3, 0, 1, 5, 5, 20, 30, 48, 34, 38, 33, 33, 28, 38, 26, 36, 41, 20, 30, 25, 16, 1, '2022-06-17 12:30:56'),
(22, '2022-06-15 00:00:00', 'Mer.', 291, 'NAPS', 17, 0, 1, 0, 1, 0, 0, 1, 6, 0, 16, 25, 12, 10, 30, 4, 4, 22, 9, 29, 52, 35, 16, 4, 9, 5, '2022-06-17 12:30:57'),
(23, '2022-06-15 00:00:00', 'Mer.', 178, 'ARREDA', 1, 0, 0, 0, 0, 1, 0, 2, 7, 10, 12, 9, 5, 14, 25, 9, 4, 5, 18, 13, 15, 10, 6, 6, 3, 4, '2022-06-17 12:30:57'),
(24, '2022-06-15 00:00:00', 'Mer.', 987, 'DAA', 7, 0, 0, 0, 0, 0, 3, 7, 22, 50, 50, 50, 61, 89, 81, 49, 53, 46, 65, 99, 89, 77, 45, 26, 14, 11, '2022-06-17 12:30:57'),
(25, '2022-06-15 00:00:00', 'Mer.', 28, 'UMB', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 7, 6, 0, 2, 2, 1, 1, 1, 3, 2, 1, 0, 0, 0, '2022-06-17 12:30:57');

-- --------------------------------------------------------

--
-- Structure de la table `global_per_hour_tpe`
--

CREATE TABLE IF NOT EXISTS `global_per_hour_tpe` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_` datetime NOT NULL,
  `day` text NOT NULL,
  `nombre_author` int(11) NOT NULL,
  `bank` varchar(15) NOT NULL,
  `nbr_rejet_tech` int(11) NOT NULL,
  `pourcentage_rejet_tech` float NOT NULL,
  `h0` int(11) NOT NULL,
  `h1` int(11) NOT NULL,
  `h2` int(11) NOT NULL,
  `h3` int(11) NOT NULL,
  `h4` int(11) NOT NULL,
  `h5` int(11) NOT NULL,
  `h6` int(11) NOT NULL,
  `h7` int(11) NOT NULL,
  `h8` int(11) NOT NULL,
  `h9` int(11) NOT NULL,
  `h10` int(11) NOT NULL,
  `h11` int(11) NOT NULL,
  `h12` int(11) NOT NULL,
  `h13` int(11) NOT NULL,
  `h14` int(11) NOT NULL,
  `h15` int(11) NOT NULL,
  `h16` int(11) NOT NULL,
  `h17` int(11) NOT NULL,
  `h18` int(11) NOT NULL,
  `h19` int(11) NOT NULL,
  `h20` int(11) NOT NULL,
  `h21` int(11) NOT NULL,
  `h22` int(11) NOT NULL,
  `h23` int(11) NOT NULL,
  `date_insertion` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Contenu de la table `global_per_hour_tpe`
--

INSERT INTO `global_per_hour_tpe` (`id`, `date_`, `day`, `nombre_author`, `bank`, `nbr_rejet_tech`, `pourcentage_rejet_tech`, `h0`, `h1`, `h2`, `h3`, `h4`, `h5`, `h6`, `h7`, `h8`, `h9`, `h10`, `h11`, `h12`, `h13`, `h14`, `h15`, `h16`, `h17`, `h18`, `h19`, `h20`, `h21`, `h22`, `h23`, `date_insertion`) VALUES
(1, '2022-06-15 00:00:00', 'Mer.', 79425, 'CIH', 3, 0, 842, 447, 225, 191, 105, 243, 764, 1456, 2128, 2659, 3552, 5316, 5857, 4994, 4690, 5071, 5922, 7410, 7658, 6933, 5873, 3478, 2262, 1349, '2022-06-17 12:30:57'),
(2, '2022-06-15 00:00:00', 'Mer.', 1535, 'BKS', 0, 0, 1, 1, 4, 2, 3, 5, 22, 49, 46, 53, 88, 141, 139, 77, 69, 85, 116, 162, 141, 141, 85, 53, 35, 17, '2022-06-17 12:30:57'),
(3, '2022-06-15 00:00:00', 'Mer.', 83828, 'BCP', 333, 0, 548, 296, 178, 133, 111, 275, 857, 1885, 2696, 3683, 4591, 6141, 6185, 5364, 4955, 5580, 6427, 7509, 7824, 6888, 5596, 2970, 2131, 1005, '2022-06-17 12:30:57'),
(4, '2022-06-15 00:00:00', 'Mer.', 18137, 'BARID', 213, 0, 144, 143, 108, 35, 24, 64, 196, 303, 482, 754, 926, 1263, 1221, 1068, 1028, 1083, 1342, 1612, 1746, 1748, 1461, 695, 439, 252, '2022-06-17 12:30:57'),
(5, '2022-06-15 00:00:00', 'Mer.', 37277, 'SGMB', 1, 0, 276, 122, 135, 49, 58, 100, 336, 956, 1296, 1745, 2176, 2906, 3031, 2469, 2220, 2376, 2813, 3318, 3381, 2845, 2238, 1274, 717, 440, '2022-06-17 12:30:57'),
(6, '2022-06-15 00:00:00', 'Mer.', 83758, 'AWB', 2, 0, 638, 379, 205, 152, 120, 290, 817, 1666, 2835, 3760, 4918, 6349, 6481, 5512, 5275, 5655, 6410, 7345, 7692, 6383, 5278, 2944, 1693, 961, '2022-06-17 12:30:57'),
(7, '2022-06-15 00:00:00', 'Mer.', 519, 'B_CASH', 1, 0, 4, 3, 2, 2, 0, 0, 1, 10, 20, 22, 21, 31, 43, 28, 26, 34, 25, 39, 74, 47, 46, 12, 10, 19, '2022-06-17 12:30:57'),
(8, '2022-06-15 00:00:00', 'Mer.', 81, 'A_Bank', 2, 3, 0, 0, 0, 0, 0, 0, 0, 0, 4, 3, 6, 3, 8, 7, 8, 6, 8, 5, 7, 6, 5, 1, 2, 2, '2022-06-17 12:30:57'),
(9, '2022-06-15 00:00:00', 'Mer.', 13, 'NAJMAH', 4, 30, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 0, 1, 0, 3, 5, 0, 0, 0, 0, 0, '2022-06-17 12:30:57'),
(10, '2022-06-15 00:00:00', 'Mer.', 15032, 'BMCI', 8, 0, 107, 27, 29, 12, 15, 69, 163, 368, 586, 735, 930, 1212, 1173, 1107, 874, 1018, 1156, 1333, 1367, 1068, 810, 485, 248, 140, '2022-06-17 12:30:57'),
(11, '2022-06-15 00:00:00', 'Mer.', 10928, 'CAM', 1, 0, 70, 59, 19, 22, 15, 55, 113, 227, 348, 535, 667, 827, 825, 672, 663, 738, 832, 855, 935, 861, 724, 402, 267, 197, '2022-06-17 12:30:57'),
(12, '2022-06-15 00:00:00', 'Mer.', 47, 'D_CASH', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 8, 4, 6, 2, 7, 0, 1, 3, 7, 2, 1, 4, 0, 1, 0, '2022-06-17 12:30:57'),
(13, '2022-06-15 00:00:00', 'Mer.', 566, 'C_plus', 0, 0, 5, 2, 0, 1, 1, 3, 4, 15, 26, 56, 44, 49, 52, 42, 36, 32, 32, 29, 56, 33, 21, 12, 6, 9, '2022-06-17 12:30:57'),
(14, '2022-06-15 00:00:00', 'Mer.', 386, 'AKB', 1, 0, 1, 0, 0, 0, 0, 1, 4, 13, 19, 17, 19, 28, 23, 17, 15, 20, 29, 33, 41, 44, 34, 14, 8, 6, '2022-06-17 12:30:57'),
(15, '2022-06-15 00:00:00', 'Mer.', 19138, 'CDM', 7, 0, 126, 64, 34, 34, 22, 69, 189, 370, 696, 1010, 1140, 1488, 1486, 1318, 1218, 1307, 1469, 1653, 1619, 1420, 1143, 606, 446, 211, '2022-06-17 12:30:57'),
(16, '2022-06-15 00:00:00', 'Mer.', 2033, 'UMNIA', 10, 0, 4, 1, 2, 1, 4, 4, 27, 56, 71, 80, 90, 156, 164, 107, 108, 143, 163, 202, 198, 179, 132, 66, 55, 20, '2022-06-17 12:30:57'),
(17, '2022-06-15 00:00:00', 'Mer.', 9, 'CDG', 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 2, 0, 3, 0, 0, 1, 0, 0, 0, '2022-06-17 12:30:57'),
(18, '2022-06-15 00:00:00', 'Mer.', 49895, 'BMCE', 5, 0, 411, 219, 140, 99, 85, 173, 487, 1100, 1703, 2273, 2892, 3706, 3708, 3268, 3135, 3249, 3847, 4340, 4397, 3857, 3265, 1816, 1093, 632, '2022-06-17 12:30:57'),
(19, '2022-06-15 00:00:00', 'Mer.', 6563, 'CFG', 36, 0, 69, 42, 22, 6, 8, 21, 52, 121, 223, 309, 376, 486, 542, 505, 438, 494, 469, 542, 527, 457, 350, 236, 150, 118, '2022-06-17 12:30:57'),
(20, '2022-06-15 00:00:00', 'Mer.', 422, 'BAY', 0, 0, 4, 2, 0, 0, 0, 2, 4, 11, 15, 30, 20, 24, 42, 38, 15, 23, 37, 29, 28, 38, 35, 13, 9, 3, '2022-06-17 12:30:57'),
(21, '2022-06-15 00:00:00', 'Mer.', 782, 'DAA', 5, 0, 4, 3, 2, 1, 3, 4, 13, 25, 40, 22, 45, 44, 55, 57, 39, 45, 56, 72, 82, 69, 53, 23, 18, 7, '2022-06-17 12:30:57'),
(22, '2022-06-15 00:00:00', 'Mer.', 441, 'NAPS', 0, 0, 7, 0, 0, 0, 0, 0, 5, 3, 14, 27, 43, 57, 42, 29, 23, 27, 29, 32, 39, 23, 17, 18, 6, 0, '2022-06-17 12:30:57'),
(23, '2022-06-15 00:00:00', 'Mer.', 122, 'ARREDA', 9, 7, 0, 0, 3, 0, 0, 0, 1, 8, 4, 11, 4, 8, 5, 8, 4, 7, 7, 9, 15, 10, 7, 5, 1, 5, '2022-06-17 12:30:57'),
(24, '2022-06-15 00:00:00', 'Mer.', 15, 'UMB', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 3, 0, 1, 1, 0, 1, 0, 2, 3, 0, 0, 0, '2022-06-17 12:30:57');

-- --------------------------------------------------------

--
-- Structure de la table `proccessing_list`
--

CREATE TABLE IF NOT EXISTS `proccessing_list` (
  `proccessing_code` varchar(2) NOT NULL,
  `abrv_wording` varchar(20) NOT NULL,
  `wording` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Contenu de la table `proccessing_list`
--

INSERT INTO `proccessing_list` (`proccessing_code`, `abrv_wording`, `wording`) VALUES
('00', 'PURCHASE', 'PURCHASES & SERVICES'),
('01', 'WITHDRAWAL', 'WITHDRAWAL'),
('02', 'DEBIT ADJUSTMENT', 'Debit Adjustment'),
('03', 'GUARANTEE CHEQUE', 'Guarantee Cheque'),
('04', 'CHEQUE DEPOSIT', 'Cheque Deposit'),
('05', 'CHEQUE VERIF', 'Cheque verification'),
('06', 'TRAVELER‘S CHECK', 'Traveler‘s check'),
('07', 'LETTER OF CREDIT', 'Letter of credit'),
('08', 'CASH DEPOSIT', 'Cash Deposit'),
('09', 'CASH BACK', 'Cash Back'),
('11', 'QUASI CASH', 'Quasi Cash'),
('14', 'CASH ADV REV', 'Cash advance reversal'),
('15', 'WITHDRAWAL REV', 'Withdrawal reversal'),
('17', 'CASH ADVC', 'Manual Cash advance'),
('18', 'DOCUMENT DEPOSIT', 'Document Deposit'),
('19', 'CASH BACK REV', 'Cash back reversal'),
('20', 'REFUND', 'Refund'),
('21', 'DEPOSIT', 'Deposit'),
('22', 'CREDIT REV', 'Credit reversal'),
('30', 'AUTHENTICAT RQST', 'Authentication Request'),
('31', 'BALANCE INQUIRY', 'Balance Inquiry'),
('32', 'ADDRESS VERIF', 'Address verification request'),
('33', 'TELECODE VERIF', 'Tele code verification request'),
('35', 'ACQ AUTH TRX', 'Acquirer authorized transaction'),
('38', 'STATMNT RQ', 'Statement request'),
('39', 'CHECKBOOK RQST', 'CheckBook Request'),
('40', 'TRANSFER REQ', 'Transfer request'),
('50', 'BILL PAYMENT', 'Bill Payment'),
('88', 'ACCOUNT LIST', 'Account list'),
('90', 'E-COMMERCE TRX', 'E-commerce transactions'),
('91', 'PIN-CHANGE', 'PIN CHANGE REQUEST'),
('92', 'LOAN REQUEST', 'Loan Request'),
('93', 'LOAN REFUND', 'Loan Refund'),
('94', 'REDEMPTION', 'Redemption'),
('6D', 'CASH PAYMENT', 'Cash Payment'),
('6A', 'CHEQUE DEPOSIT', 'Cheque deposit'),
('6E', 'PYMT WAIT. CONF', 'Payment Waiting Conf'),
('24', 'CHEQUE DEPOSIT', 'Cheque Deposit'),
('95', 'TOP UP', 'Top Up'),
('26', 'Original Credit', 'VISA MONEY TRANSFERT LOAD'),
('28', 'PAYMENT', 'Payment'),
('89', 'COST OF TXN', 'COST OF TRANSACTION'),
('81', 'CARD VERIFICATIO', 'CARD VERIFICATIO');

-- --------------------------------------------------------

--
-- Structure de la table `reject_per_hour_all`
--

CREATE TABLE IF NOT EXISTS `reject_per_hour_all` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_` datetime NOT NULL,
  `day` text NOT NULL,
  `bank` varchar(15) NOT NULL,
  `nbr` int(11) NOT NULL,
  `h0` int(11) NOT NULL,
  `h1` int(11) NOT NULL,
  `h2` int(11) NOT NULL,
  `h3` int(11) NOT NULL,
  `h4` int(11) NOT NULL,
  `h5` int(11) NOT NULL,
  `h6` int(11) NOT NULL,
  `h7` int(11) NOT NULL,
  `h8` int(11) NOT NULL,
  `h9` int(11) NOT NULL,
  `h10` int(11) NOT NULL,
  `h11` int(11) NOT NULL,
  `h12` int(11) NOT NULL,
  `h13` int(11) NOT NULL,
  `h14` int(11) NOT NULL,
  `h15` int(11) NOT NULL,
  `h16` int(11) NOT NULL,
  `h17` int(11) NOT NULL,
  `h18` int(11) NOT NULL,
  `h19` int(11) NOT NULL,
  `h20` int(11) NOT NULL,
  `h21` int(11) NOT NULL,
  `h22` int(11) NOT NULL,
  `h23` int(11) NOT NULL,
  `date_insertion` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=21 ;

--
-- Contenu de la table `reject_per_hour_all`
--

INSERT INTO `reject_per_hour_all` (`id`, `date_`, `day`, `bank`, `nbr`, `h0`, `h1`, `h2`, `h3`, `h4`, `h5`, `h6`, `h7`, `h8`, `h9`, `h10`, `h11`, `h12`, `h13`, `h14`, `h15`, `h16`, `h17`, `h18`, `h19`, `h20`, `h21`, `h22`, `h23`, `date_insertion`) VALUES
(1, '2022-06-15 00:00:00', 'Mer.', 'CIH', 5, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, '2022-06-16 16:56:48'),
(2, '2022-06-15 00:00:00', 'Mer.', 'BKS', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2022-06-16 16:56:48'),
(3, '2022-06-15 00:00:00', 'Mer.', 'BCP', 375, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 369, 0, '2022-06-16 16:56:48'),
(4, '2022-06-15 00:00:00', 'Mer.', 'SGMB', 16, 0, 1, 0, 0, 0, 0, 0, 0, 3, 1, 1, 3, 1, 0, 0, 0, 1, 1, 0, 0, 4, 0, 0, 0, '2022-06-16 16:56:48'),
(5, '2022-06-15 00:00:00', 'Mer.', 'AWB', 4, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 1, 0, 0, 0, '2022-06-16 16:56:48'),
(6, '2022-06-15 00:00:00', 'Mer.', 'BARID', 634, 0, 258, 264, 1, 0, 1, 3, 2, 2, 9, 1, 3, 9, 2, 7, 7, 10, 5, 6, 9, 22, 6, 4, 3, '2022-06-16 16:56:48'),
(7, '2022-06-15 00:00:00', 'Mer.', 'Arab_Bank', 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 0, 2, 0, 0, 2, 0, 0, 0, 0, 5, '2022-06-16 16:56:48'),
(8, '2022-06-15 00:00:00', 'Mer.', 'NAJMAH', 5, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 0, '2022-06-16 16:56:48'),
(9, '2022-06-15 00:00:00', 'Mer.', 'BARID_CASH', 35, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 6, 2, 5, 4, 3, 0, 3, 6, 2, 0, 0, 2, '2022-06-16 16:56:48'),
(10, '2022-06-15 00:00:00', 'Mer.', 'BMCI', 37, 0, 0, 2, 0, 0, 1, 2, 0, 0, 4, 2, 1, 0, 2, 1, 6, 0, 2, 7, 3, 0, 1, 2, 1, '2022-06-16 16:56:48'),
(11, '2022-06-15 00:00:00', 'Mer.', 'CAM', 5, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 0, '2022-06-16 16:56:48'),
(12, '2022-06-15 00:00:00', 'Mer.', 'AKB', 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, '2022-06-16 16:56:48'),
(13, '2022-06-15 00:00:00', 'Mer.', 'CDM', 8, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2022-06-16 16:56:48'),
(14, '2022-06-15 00:00:00', 'Mer.', 'UMNIA', 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 14, 0, '2022-06-16 16:56:48'),
(15, '2022-06-15 00:00:00', 'Mer.', 'BMCE', 251, 3, 2, 4, 0, 9, 2, 0, 0, 4, 21, 15, 21, 9, 12, 8, 5, 8, 21, 26, 24, 18, 19, 16, 4, '2022-06-16 16:56:48'),
(16, '2022-06-15 00:00:00', 'Mer.', 'CFG', 43, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 9, 0, 34, 0, 0, 0, 0, 0, 0, 0, 0, '2022-06-16 16:56:48'),
(17, '2022-06-15 00:00:00', 'Mer.', 'NAPS', 19, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 2, 1, 2, 0, 0, 0, 0, 3, 6, 3, 0, 0, 1, 0, '2022-06-16 16:56:48'),
(18, '2022-06-15 00:00:00', 'Mer.', 'ARREDA', 9, 0, 0, 3, 0, 0, 0, 0, 0, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2022-06-16 16:56:48'),
(19, '2022-06-15 00:00:00', 'Mer.', 'DAA', 12, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 3, 1, 0, 0, 0, 0, 0, 0, 5, 0, 0, 0, '2022-06-16 16:56:48'),
(20, '2022-06-15 00:00:00', 'Mer.', 'BAY', 3, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, '2022-06-16 16:56:48');

-- --------------------------------------------------------

--
-- Structure de la table `reject_per_hour_atm`
--

CREATE TABLE IF NOT EXISTS `reject_per_hour_atm` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_` datetime NOT NULL,
  `day` text NOT NULL,
  `bank` varchar(15) NOT NULL,
  `nbr` int(11) NOT NULL,
  `h0` int(11) NOT NULL,
  `h1` int(11) NOT NULL,
  `h2` int(11) NOT NULL,
  `h3` int(11) NOT NULL,
  `h4` int(11) NOT NULL,
  `h5` int(11) NOT NULL,
  `h6` int(11) NOT NULL,
  `h7` int(11) NOT NULL,
  `h8` int(11) NOT NULL,
  `h9` int(11) NOT NULL,
  `h10` int(11) NOT NULL,
  `h11` int(11) NOT NULL,
  `h12` int(11) NOT NULL,
  `h13` int(11) NOT NULL,
  `h14` int(11) NOT NULL,
  `h15` int(11) NOT NULL,
  `h16` int(11) NOT NULL,
  `h17` int(11) NOT NULL,
  `h18` int(11) NOT NULL,
  `h19` int(11) NOT NULL,
  `h20` int(11) NOT NULL,
  `h21` int(11) NOT NULL,
  `h22` int(11) NOT NULL,
  `h23` int(11) NOT NULL,
  `date_insertion` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Contenu de la table `reject_per_hour_atm`
--

INSERT INTO `reject_per_hour_atm` (`id`, `date_`, `day`, `bank`, `nbr`, `h0`, `h1`, `h2`, `h3`, `h4`, `h5`, `h6`, `h7`, `h8`, `h9`, `h10`, `h11`, `h12`, `h13`, `h14`, `h15`, `h16`, `h17`, `h18`, `h19`, `h20`, `h21`, `h22`, `h23`, `date_insertion`) VALUES
(1, '2022-06-15 00:00:00', 'Mer.', 'CIH', 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 0, 0, '2022-06-16 17:00:32'),
(2, '2022-06-15 00:00:00', 'Mer.', 'BKS', 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2022-06-16 17:00:32'),
(3, '2022-06-15 00:00:00', 'Mer.', 'BCP', 37, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 36, 0, '2022-06-16 17:00:32'),
(4, '2022-06-15 00:00:00', 'Mer.', 'SGMB', 15, 0, 0, 0, 0, 0, 0, 0, 0, 3, 1, 1, 3, 1, 0, 0, 0, 1, 1, 0, 0, 4, 0, 0, 0, '2022-06-16 17:00:32'),
(5, '2022-06-15 00:00:00', 'Mer.', 'AWB', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, '2022-06-16 17:00:32'),
(6, '2022-06-15 00:00:00', 'Mer.', 'BARID', 364, 0, 148, 162, 0, 0, 1, 2, 1, 0, 7, 0, 0, 6, 0, 1, 1, 2, 5, 4, 6, 14, 0, 3, 1, '2022-06-16 17:00:32'),
(7, '2022-06-15 00:00:00', 'Mer.', 'Arab_Bank', 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 0, 0, 0, 0, 1, 0, 0, 0, 0, 3, '2022-06-16 17:00:32'),
(8, '2022-06-15 00:00:00', 'Mer.', 'NAJMAH', 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2022-06-16 17:00:32'),
(9, '2022-06-15 00:00:00', 'Mer.', 'BARID_CASH', 34, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 6, 2, 5, 4, 3, 0, 3, 6, 2, 0, 0, 1, '2022-06-16 17:00:32'),
(10, '2022-06-15 00:00:00', 'Mer.', 'BMCI', 22, 0, 0, 2, 0, 0, 1, 2, 0, 0, 1, 2, 1, 0, 2, 1, 4, 0, 1, 2, 2, 0, 0, 0, 1, '2022-06-16 17:00:32'),
(11, '2022-06-15 00:00:00', 'Mer.', 'CAM', 3, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, '2022-06-16 17:00:32'),
(12, '2022-06-15 00:00:00', 'Mer.', 'AKB', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, '2022-06-16 17:00:32'),
(13, '2022-06-15 00:00:00', 'Mer.', 'CDM', 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2022-06-16 17:00:32'),
(14, '2022-06-15 00:00:00', 'Mer.', 'UMNIA', 5, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 4, 0, '2022-06-16 17:00:32'),
(15, '2022-06-15 00:00:00', 'Mer.', 'BMCE', 141, 0, 0, 0, 0, 9, 0, 0, 0, 2, 15, 7, 17, 4, 5, 3, 4, 1, 13, 14, 15, 6, 11, 13, 2, '2022-06-16 17:00:32'),
(16, '2022-06-15 00:00:00', 'Mer.', 'CFG', 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 6, 0, 0, 0, 0, 0, 0, 0, 0, '2022-06-16 17:00:32'),
(17, '2022-06-15 00:00:00', 'Mer.', 'NAPS', 17, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 2, 0, 0, 0, 0, 3, 6, 3, 0, 0, 1, 0, '2022-06-16 17:00:32'),
(18, '2022-06-15 00:00:00', 'Mer.', 'DAA', 7, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 0, 2, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, '2022-06-16 17:00:32'),
(19, '2022-06-15 00:00:00', 'Mer.', 'BAY', 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '2022-06-16 17:00:32');

-- --------------------------------------------------------

--
-- Structure de la table `stat_file_buffer_dispo`
--

CREATE TABLE IF NOT EXISTS `stat_file_buffer_dispo` (
  `id_auto` int(11) NOT NULL AUTO_INCREMENT,
  `sequence_number` int(11) NOT NULL,
  `bank_code` int(6) unsigned zerofill NOT NULL,
  `date_courant` date NOT NULL,
  `activity_date` date NOT NULL,
  `date_debut` datetime NOT NULL,
  `date_fin` datetime NOT NULL,
  `Downtime_en_min` int(11) NOT NULL,
  `Downtime_en_sec` int(11) NOT NULL,
  PRIMARY KEY (`id_auto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `stat_file_buffer_mcc`
--

CREATE TABLE IF NOT EXISTS `stat_file_buffer_mcc` (
  `id_auto` int(11) NOT NULL AUTO_INCREMENT,
  `sequence_number` int(11) NOT NULL,
  `date_courant` date NOT NULL,
  `nbr_trx` int(11) NOT NULL,
  `issuing_bank` varchar(8) NOT NULL,
  `acquring_bank` varchar(8) NOT NULL,
  `processing_code` varchar(30) NOT NULL,
  `action_code` varchar(30) NOT NULL,
  `mcc_code` int(11) NOT NULL,
  `activity_hour` int(11) NOT NULL,
  `activity_date` date NOT NULL,
  `description` varchar(100) NOT NULL,
  `pos_data_mode` varchar(2) NOT NULL,
  `pos_data_capacite` varchar(2) NOT NULL,
  `activityy_date` date NOT NULL,
  PRIMARY KEY (`id_auto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `stat_file_buffer_pick`
--

CREATE TABLE IF NOT EXISTS `stat_file_buffer_pick` (
  `id_auto` int(11) NOT NULL AUTO_INCREMENT,
  `sequence_number` int(11) NOT NULL,
  `date_courant` date NOT NULL,
  `buffer_1` int(11) NOT NULL,
  `date_create` date NOT NULL,
  `buffer_3` int(11) NOT NULL,
  `buffer_4` int(11) NOT NULL,
  `activity_date` date NOT NULL,
  PRIMARY KEY (`id_auto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `stat_file_buffer_rejet`
--

CREATE TABLE IF NOT EXISTS `stat_file_buffer_rejet` (
  `id_auto` int(11) NOT NULL AUTO_INCREMENT,
  `sequence_number` int(11) NOT NULL,
  `date_courant` date NOT NULL,
  `bank_code` int(6) unsigned zerofill NOT NULL,
  `activity_date` date NOT NULL,
  `acq_iss_flag` varchar(3) NOT NULL,
  `action_code` int(11) NOT NULL,
  `nb_action_code` int(11) NOT NULL,
  PRIMARY KEY (`id_auto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `stat_file_buffer_time`
--

CREATE TABLE IF NOT EXISTS `stat_file_buffer_time` (
  `id_auto` int(11) NOT NULL AUTO_INCREMENT,
  `sequence_number` int(11) NOT NULL,
  `date_courant` date NOT NULL,
  `bank_code` int(6) unsigned zerofill NOT NULL,
  `date_create` date NOT NULL,
  `activity_date` date NOT NULL,
  `request` float NOT NULL,
  `response` float NOT NULL,
  `time_hpss` float NOT NULL,
  PRIMARY KEY (`id_auto`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `stat_file_rejet_per_hour`
--

CREATE TABLE IF NOT EXISTS `stat_file_rejet_per_hour` (
  `id_auto` int(11) NOT NULL AUTO_INCREMENT,
  `date_courant` date NOT NULL,
  `date_autho` date NOT NULL,
  `day_autho` varchar(10) NOT NULL,
  `nbr_autho` int(11) NOT NULL,
  `bank_name` varchar(15) NOT NULL,
  `nbr_tech_reject` int(11) NOT NULL,
  `percentage_tech_reject` float NOT NULL,
  `percentage_reject_categ_banque` float NOT NULL,
  `percentage_reject_global` float NOT NULL,
  `h0` int(11) NOT NULL,
  `h1` int(11) NOT NULL,
  `h2` int(11) NOT NULL,
  `h3` int(11) NOT NULL,
  `h4` int(11) NOT NULL,
  `h5` int(11) NOT NULL,
  `h6` int(11) NOT NULL,
  `h7` int(11) NOT NULL,
  `h8` int(11) NOT NULL,
  `h9` int(11) NOT NULL,
  `h10` int(11) NOT NULL,
  `h11` int(11) NOT NULL,
  `h12` int(11) NOT NULL,
  `h13` int(11) NOT NULL,
  `h14` int(11) NOT NULL,
  `h15` int(11) NOT NULL,
  `h16` int(11) NOT NULL,
  `h17` int(11) NOT NULL,
  `h18` int(11) NOT NULL,
  `h19` int(11) NOT NULL,
  `h20` int(11) NOT NULL,
  `h21` int(11) NOT NULL,
  `h22` int(11) NOT NULL,
  `h23` int(11) NOT NULL,
  `user_create` varchar(15) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_modif` varchar(15) NOT NULL,
  `date_modif` date NOT NULL,
  PRIMARY KEY (`id_auto`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=661 ;

--
-- Contenu de la table `stat_file_rejet_per_hour`
--

INSERT INTO `stat_file_rejet_per_hour` (`id_auto`, `date_courant`, `date_autho`, `day_autho`, `nbr_autho`, `bank_name`, `nbr_tech_reject`, `percentage_tech_reject`, `percentage_reject_categ_banque`, `percentage_reject_global`, `h0`, `h1`, `h2`, `h3`, `h4`, `h5`, `h6`, `h7`, `h8`, `h9`, `h10`, `h11`, `h12`, `h13`, `h14`, `h15`, `h16`, `h17`, `h18`, `h19`, `h20`, `h21`, `h22`, `h23`, `user_create`, `date_create`, `user_modif`, `date_modif`) VALUES
(641, '2022-05-13', '0000-00-00', 'Wed', 27339, 'CDM', 22, 0.08, 1.04, 1.01, 0, 0, 0, 0, 0, 0, 0, 4, 2, 0, 3, 1, 2, 0, 0, 0, 1, 0, 0, 0, 0, 9, 0, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(642, '2022-05-13', '0000-00-00', 'Wed', 7951, 'CFG', 11, 0.14, 0.52, 0.51, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 1, 1, 0, 0, 0, 0, 0, 6, 0, 1, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(643, '2022-05-13', '0000-00-00', 'Wed', 109207, 'AWB', 327, 0.3, 15.53, 15.03, 1, 0, 0, 0, 0, 0, 0, 0, 0, 48, 244, 4, 1, 2, 2, 7, 7, 3, 1, 2, 0, 5, 0, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(644, '2022-05-13', '0000-00-00', 'Wed', 5060, 'UMNIA', 13, 0.26, 0.62, 0.6, 0, 0, 0, 0, 0, 0, 0, 0, 1, 6, 0, 0, 1, 0, 1, 1, 0, 1, 1, 1, 0, 0, 0, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(645, '2022-05-13', '0000-00-00', 'Wed', 678, 'NAPS', 7, 1.03, 10, 0.32, 0, 0, 2, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(646, '2022-05-13', '0000-00-00', 'Wed', 61, 'UMB', 1, 1.64, 1.43, 0.05, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(647, '2022-05-13', '0000-00-00', 'Wed', 294, 'ARREDA', 2, 0.68, 2.86, 0.09, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(648, '2022-05-13', '0000-00-00', 'Wed', 3996, 'BARID_CASH', 11, 0.28, 15.71, 0.51, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 2, 2, 0, 2, 0, 0, 2, 0, 0, 2, 0, 0, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(649, '2022-05-13', '0000-00-00', 'Wed', 98766, 'BCP', 27, 0.03, 1.28, 1.24, 1, 0, 0, 0, 0, 0, 1, 0, 1, 1, 0, 5, 2, 0, 1, 0, 1, 3, 1, 4, 3, 2, 1, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(650, '2022-05-13', '0000-00-00', 'Wed', 35741, 'BARID', 339, 0.95, 16.1, 15.58, 1, 252, 0, 0, 2, 0, 2, 0, 0, 1, 9, 9, 2, 6, 5, 2, 6, 14, 8, 3, 9, 6, 0, 2, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(651, '2022-05-13', '0000-00-00', 'Wed', 90, 'DAMAN_CASH', 29, 32.22, 41.43, 1.33, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 0, 1, 4, 0, 2, 1, 2, 16, 0, 0, 0, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(652, '2022-05-13', '0000-00-00', 'Wed', 106604, 'CIH', 472, 0.44, 22.41, 21.69, 3, 0, 0, 1, 0, 0, 1, 1, 4, 29, 6, 3, 4, 5, 1, 0, 3, 3, 3, 8, 0, 3, 394, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(653, '2022-05-13', '0000-00-00', 'Wed', 18601, 'CAM', 120, 0.65, 5.7, 5.51, 0, 0, 0, 0, 1, 1, 1, 2, 6, 1, 9, 8, 2, 8, 7, 6, 11, 15, 6, 11, 11, 7, 7, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(654, '2022-05-13', '0000-00-00', 'Wed', 49190, 'SGMB', 36, 0.07, 1.71, 1.65, 0, 0, 0, 0, 0, 0, 2, 0, 1, 0, 4, 3, 2, 2, 6, 1, 3, 3, 3, 1, 2, 3, 0, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(655, '2022-05-13', '0000-00-00', 'Wed', 1733, 'DAA', 6, 0.35, 0.28, 0.28, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1, 1, 0, 3, 0, 0, 0, 0, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(656, '2022-05-13', '0000-00-00', 'Wed', 20993, 'BMCI', 87, 0.41, 4.13, 4, 1, 0, 0, 0, 0, 0, 0, 5, 1, 4, 7, 2, 4, 8, 2, 6, 7, 15, 12, 3, 6, 0, 3, 1, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(657, '2022-05-13', '0000-00-00', 'Wed', 65359, 'BMCE', 646, 0.99, 30.67, 29.69, 2, 0, 1, 0, 0, 2, 7, 6, 8, 7, 14, 16, 18, 26, 9, 8, 13, 42, 20, 29, 15, 7, 9, 387, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(658, '2022-05-13', '0000-00-00', 'Wed', 799, 'AKB', 2, 0.25, 2.86, 0.09, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(659, '2022-05-13', '0000-00-00', 'Wed', 1153, 'Cash_plus', 3, 0.26, 4.29, 0.14, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 2, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(660, '2022-05-13', '0000-00-00', 'Wed', 4277, 'BKS', 15, 0.35, 21.43, 0.69, 0, 0, 0, 0, 0, 0, 1, 1, 0, 2, 3, 1, 0, 0, 0, 5, 1, 1, 0, 0, 0, 0, 0, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00');

-- --------------------------------------------------------

--
-- Structure de la table `stat_file_rejet_per_hour_gl`
--

CREATE TABLE IF NOT EXISTS `stat_file_rejet_per_hour_gl` (
  `id_auto` int(11) NOT NULL AUTO_INCREMENT,
  `date_courant` date NOT NULL,
  `date_autho` date NOT NULL,
  `day_autho` varchar(10) NOT NULL,
  `nbr_autho` int(11) NOT NULL,
  `bank_name` varchar(15) NOT NULL,
  `nbr_tech_reject` int(11) NOT NULL,
  `percentage_tech_reject` float NOT NULL,
  `percentage_auto_categ_banque` float NOT NULL,
  `percentage_auto_global` float NOT NULL,
  `h0` int(11) NOT NULL,
  `h1` int(11) NOT NULL,
  `h2` int(11) NOT NULL,
  `h3` int(11) NOT NULL,
  `h4` int(11) NOT NULL,
  `h5` int(11) NOT NULL,
  `h6` int(11) NOT NULL,
  `h7` int(11) NOT NULL,
  `h8` int(11) NOT NULL,
  `h9` int(11) NOT NULL,
  `h10` int(11) NOT NULL,
  `h11` int(11) NOT NULL,
  `h12` int(11) NOT NULL,
  `h13` int(11) NOT NULL,
  `h14` int(11) NOT NULL,
  `h15` int(11) NOT NULL,
  `h16` int(11) NOT NULL,
  `h17` int(11) NOT NULL,
  `h18` int(11) NOT NULL,
  `h19` int(11) NOT NULL,
  `h20` int(11) NOT NULL,
  `h21` int(11) NOT NULL,
  `h22` int(11) NOT NULL,
  `h23` int(11) NOT NULL,
  `user_create` varchar(15) NOT NULL,
  `date_create` datetime NOT NULL,
  `user_modif` varchar(15) NOT NULL,
  `date_modif` date NOT NULL,
  PRIMARY KEY (`id_auto`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=376 ;

--
-- Contenu de la table `stat_file_rejet_per_hour_gl`
--

INSERT INTO `stat_file_rejet_per_hour_gl` (`id_auto`, `date_courant`, `date_autho`, `day_autho`, `nbr_autho`, `bank_name`, `nbr_tech_reject`, `percentage_tech_reject`, `percentage_auto_categ_banque`, `percentage_auto_global`, `h0`, `h1`, `h2`, `h3`, `h4`, `h5`, `h6`, `h7`, `h8`, `h9`, `h10`, `h11`, `h12`, `h13`, `h14`, `h15`, `h16`, `h17`, `h18`, `h19`, `h20`, `h21`, `h22`, `h23`, `user_create`, `date_create`, `user_modif`, `date_modif`) VALUES
(351, '2022-05-13', '0000-00-00', 'Wed', 27339, 'CDM', 22, 0.08, 1.04, 1.01, 190, 99, 81, 66, 58, 103, 274, 768, 1121, 1421, 1718, 2184, 2125, 1717, 1703, 1791, 2228, 2243, 2302, 1879, 1511, 858, 564, 335, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(352, '2022-05-13', '0000-00-00', 'Wed', 7951, 'CFG', 11, 0.14, 0.52, 0.51, 92, 44, 21, 23, 14, 18, 55, 171, 328, 399, 486, 680, 662, 564, 482, 515, 608, 663, 648, 495, 341, 326, 202, 114, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(353, '2022-05-13', '0000-00-00', 'Wed', 124, 'Cetelem', 0, 0, 0, 0, 0, 0, 0, 6, 1, 0, 0, 3, 2, 4, 9, 13, 6, 9, 6, 6, 22, 13, 4, 6, 6, 7, 1, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(354, '2022-05-13', '0000-00-00', 'Wed', 109207, 'AWB', 327, 0.3, 15.53, 15.03, 778, 453, 282, 266, 181, 342, 1040, 2447, 3973, 5517, 7501, 8012, 8180, 7151, 6880, 7124, 8356, 9256, 9707, 8134, 6347, 3640, 2324, 1316, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(355, '2022-05-13', '0000-00-00', 'Wed', 5060, 'UMNIA', 13, 0.26, 0.62, 0.6, 14, 4, 3, 1, 9, 21, 45, 180, 217, 281, 288, 398, 364, 311, 289, 273, 329, 494, 488, 388, 320, 208, 93, 42, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(356, '2022-05-13', '0000-00-00', 'Wed', 678, 'NAPS', 7, 1.03, 10, 0.32, 2, 1, 4, 0, 5, 4, 5, 5, 31, 44, 68, 69, 61, 36, 29, 46, 49, 72, 37, 44, 32, 21, 9, 4, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(357, '2022-05-13', '0000-00-00', 'Wed', 1085, 'BAY', 0, 0, 0, 0, 6, 3, 0, 3, 1, 5, 17, 34, 54, 38, 60, 113, 74, 74, 63, 71, 85, 97, 95, 65, 56, 37, 27, 7, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(358, '2022-05-13', '0000-00-00', 'Wed', 3996, 'BARID_CASH', 11, 0.28, 15.71, 0.51, 19, 9, 4, 4, 5, 20, 76, 135, 196, 199, 294, 250, 319, 223, 238, 228, 320, 342, 420, 258, 220, 126, 61, 30, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(359, '2022-05-13', '0000-00-00', 'Wed', 294, 'ARREDA', 2, 0.68, 2.86, 0.09, 0, 2, 0, 0, 0, 1, 3, 14, 10, 12, 16, 19, 22, 11, 7, 21, 22, 27, 45, 32, 15, 6, 8, 1, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(360, '2022-05-13', '0000-00-00', 'Wed', 61, 'UMB', 1, 1.64, 1.43, 0.05, 0, 0, 0, 0, 0, 0, 7, 1, 1, 5, 3, 11, 6, 3, 2, 3, 5, 6, 0, 1, 5, 2, 0, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(361, '2022-05-13', '0000-00-00', 'Wed', 98766, 'BCP', 27, 0.03, 1.28, 1.24, 698, 343, 236, 167, 165, 358, 893, 2229, 3426, 4485, 5718, 7225, 7433, 6523, 6115, 6577, 7774, 8808, 9037, 8004, 6158, 3182, 2063, 1149, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(362, '2022-05-13', '0000-00-00', 'Wed', 35741, 'BARID', 339, 0.95, 16.1, 15.58, 273, 323, 69, 53, 78, 183, 467, 793, 1336, 1749, 2213, 2600, 2291, 2116, 2027, 2255, 2518, 3123, 3460, 3053, 2388, 1239, 791, 343, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(363, '2022-05-13', '0000-00-00', 'Wed', 7, 'CDG', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 4, 0, 0, 0, 1, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(364, '2022-05-13', '0000-00-00', 'Wed', 90, 'DAMAN_CASH', 29, 32.22, 41.43, 1.33, 0, 0, 0, 0, 0, 0, 0, 0, 3, 3, 7, 2, 4, 13, 10, 6, 3, 4, 4, 29, 1, 0, 1, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(365, '2022-05-13', '0000-00-00', 'Wed', 106604, 'CIH', 472, 0.44, 22.41, 21.69, 953, 511, 289, 186, 146, 350, 1056, 2118, 2913, 4077, 5222, 7455, 8228, 6924, 6400, 6803, 7825, 9652, 10124, 9117, 7151, 4321, 3169, 1614, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(366, '2022-05-13', '0000-00-00', 'Wed', 49190, 'SGMB', 36, 0.07, 1.71, 1.65, 351, 189, 105, 72, 80, 164, 509, 1160, 1833, 2243, 2879, 3643, 3692, 3121, 2989, 3267, 3776, 4667, 4527, 3827, 2835, 1625, 1066, 570, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(367, '2022-05-13', '0000-00-00', 'Wed', 18601, 'CAM', 120, 0.65, 5.7, 5.51, 127, 78, 49, 48, 35, 85, 221, 460, 736, 1037, 1102, 1447, 1372, 1152, 1200, 1216, 1386, 1609, 1602, 1245, 1125, 604, 433, 232, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(368, '2022-05-13', '0000-00-00', 'Wed', 1733, 'DAA', 6, 0.35, 0.28, 0.28, 7, 0, 0, 1, 2, 10, 17, 61, 66, 66, 77, 138, 140, 110, 82, 120, 145, 158, 169, 113, 131, 73, 32, 15, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(369, '2022-05-13', '0000-00-00', 'Wed', 123, 'Arab_Bank', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 3, 1, 3, 16, 8, 15, 13, 6, 9, 8, 12, 15, 4, 5, 0, 2, 1, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(370, '2022-05-13', '0000-00-00', 'Wed', 57, 'NAJMAH', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 2, 4, 0, 9, 5, 4, 3, 2, 1, 9, 5, 4, 4, 3, 1, 0, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(371, '2022-05-13', '0000-00-00', 'Wed', 65359, 'BMCE', 646, 0.99, 30.67, 29.69, 523, 269, 144, 131, 119, 210, 701, 1570, 2490, 3096, 3825, 4779, 4917, 4269, 3921, 4271, 5138, 5827, 5833, 4869, 3731, 2187, 1432, 1107, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(372, '2022-05-13', '0000-00-00', 'Wed', 20993, 'BMCI', 87, 0.41, 4.13, 4, 90, 52, 28, 21, 25, 88, 207, 501, 916, 1096, 1310, 1675, 1689, 1439, 1191, 1435, 1668, 1944, 1790, 1435, 1122, 657, 407, 207, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(373, '2022-05-13', '0000-00-00', 'Wed', 799, 'AKB', 2, 0.25, 2.86, 0.09, 1, 0, 0, 0, 0, 7, 8, 26, 24, 41, 43, 51, 71, 44, 67, 51, 77, 75, 76, 50, 41, 25, 19, 2, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(374, '2022-05-13', '0000-00-00', 'Wed', 1153, 'Cash_plus', 3, 0.26, 4.29, 0.14, 9, 3, 1, 0, 0, 2, 11, 15, 46, 99, 100, 92, 87, 59, 74, 72, 88, 82, 81, 80, 52, 50, 27, 23, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00'),
(375, '2022-05-13', '0000-00-00', 'Wed', 4277, 'BKS', 15, 0.35, 21.43, 0.69, 7, 6, 2, 5, 11, 13, 62, 163, 189, 217, 236, 346, 315, 241, 257, 266, 344, 410, 361, 310, 235, 167, 82, 32, 'POWERCARD', '0000-00-00 00:00:00', '', '0000-00-00');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
